const DeleteBookForm = ({ rowObject, backendURL, refreshBook }) => {

    return (
        <td>
            <form>
                <button type='submit'>
                    Delete
                </button>
            </form>
        </td>

    );
};

export default DeleteBookForm;