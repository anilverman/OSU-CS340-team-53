const DeleteAuthorForm = ({ rowObject, backendURL, refreshAuthor }) => {

    return (
        <td>
            <form>
                <button type='submit'>
                    Delete
                </button>
            </form>
        </td>

    );
};

export default DeleteAuthorForm;