const DeleteCheckoutForm = ({ rowObject, backendURL, refreshCheckouts }) => {

    return (
        <td>
            <form>
                <button type='submit'>
                    Delete
                </button>
            </form>
        </td>

    );
};

export default DeleteCheckoutForm;