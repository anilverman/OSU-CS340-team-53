const DeleteReviewForm = ({ rowObject, backendURL, refreshReviews }) => {

    return (
        <td>
            <form>
                <button type='submit'>
                    Delete
                </button>
            </form>
        </td>

    );
};

export default DeleteReviewForm;