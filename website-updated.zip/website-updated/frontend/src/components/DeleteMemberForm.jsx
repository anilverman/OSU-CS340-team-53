const DeleteMemberForm = ({ rowObject, backendURL, refreshMembers }) => {

    return (
        <td>
            <form>
                <button type='submit'>
                    Delete
                </button>
            </form>
        </td>

    );
};

export default DeleteMemberForm;