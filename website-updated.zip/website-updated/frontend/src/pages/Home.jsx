function Home() {
    return (
        <>
            <h1>Home page</h1>
            <div className="homepageDescription">
                <p>Developer information and Project overview here.</p>
            </div>
        </>
    )
} export default Home;